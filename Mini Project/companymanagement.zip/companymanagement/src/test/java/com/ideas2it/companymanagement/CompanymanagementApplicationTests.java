package com.ideas2it.companymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanymanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
