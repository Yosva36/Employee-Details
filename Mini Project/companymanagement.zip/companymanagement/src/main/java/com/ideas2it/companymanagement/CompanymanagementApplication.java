package com.ideas2it.companymanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanymanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompanymanagementApplication.class, args);
	}

}
