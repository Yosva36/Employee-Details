package com.ideas2it.employeedetails.enums;

/**
 * Holds the well known constant fields of Gender.
 **/
public enum Gender {
    Male,
    Female,
    Others
}