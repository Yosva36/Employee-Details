package com.ideas2it.employeedetails.constants;

/** 
 * Holds common unchangeable fields.
 **/
public class EmployeeConstants {
    public static final String COMPANY_NAME = "Ideas2IT Technologies";
}
